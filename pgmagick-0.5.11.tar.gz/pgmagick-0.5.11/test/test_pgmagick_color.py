import sys
sys.path.append('../')
sys.path.append('./')
from pgmagick import Color
from pgmagick import ColorHSL
from pgmagick import ColorGray
from pgmagick import ColorMono
from pgmagick import ColorRGB
from pgmagick import ColorYUV
